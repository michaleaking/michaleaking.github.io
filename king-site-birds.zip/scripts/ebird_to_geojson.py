#!/usr/bin/env python3
"""
Convert an eBird "Download My Data" export into a GeoJSON of *life birds* —
the first time you recorded each species — for the Fun map on the website.

Get the input file:
    eBird.org -> your account -> "Download My Data" -> Submit Request.
    You'll get an email with a link to a .zip; unzip it to find MyEBirdData.csv.

Usage:
    python scripts/ebird_to_geojson.py path/to/MyEBirdData.csv

Writes:
    assets/data/life_birds.geojson   (overwrites the sample that ships with the site)

Requires: pandas  (conda install -c conda-forge pandas)

Bird photos are NOT stored here — they live in assets/data/bird_photos.json,
keyed by species, so re-running this script never overwrites them.
"""
import sys
import json
from pathlib import Path

import pandas as pd

# Set to False to keep every taxon; True drops non-species entries
# ("gull sp.", hybrids, "Mallard/American Black Duck" slashes) for a clean life list.
SPECIES_ONLY = True


def is_species(name: str) -> bool:
    name = str(name)
    if " sp." in name:            # spuh, e.g. "gull sp."
        return False
    if "/" in name:               # slash, e.g. "Snow/Ross's Goose"
        return False
    if "hybrid" in name.lower():  # hybrids
        return False
    return True


def main(csv_path: str) -> None:
    df = pd.read_csv(csv_path)

    # Columns present in eBird's MyEBirdData.csv:
    # 'Common Name','Scientific Name','Count','Location','Latitude','Longitude','Date','Time', ...
    df["Date"] = pd.to_datetime(df["Date"], errors="coerce")
    df = df.dropna(subset=["Latitude", "Longitude", "Date", "Common Name"])

    if SPECIES_ONLY:
        df = df[df["Common Name"].map(is_species)]

    # A life bird is the earliest observation of each species.
    df = df.sort_values("Date")
    firsts = df.groupby("Common Name", as_index=False).first()

    features = []
    for _, r in firsts.iterrows():
        features.append({
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [float(r["Longitude"]), float(r["Latitude"])],
            },
            "properties": {
                "common_name": r["Common Name"],
                "scientific_name": r.get("Scientific Name", ""),
                "date": r["Date"].strftime("%Y-%m-%d"),
                "location": r.get("Location", ""),
            },
        })

    fc = {"type": "FeatureCollection", "features": features}
    out = Path(__file__).resolve().parents[1] / "assets" / "data" / "life_birds.geojson"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(fc, indent=1))
    print(f"Wrote {len(features)} life birds to {out.relative_to(Path.cwd())}"
          if Path.cwd() in out.parents else f"Wrote {len(features)} life birds to {out}")


if __name__ == "__main__":
    if len(sys.argv) < 2:
        sys.exit("Usage: python scripts/ebird_to_geojson.py path/to/MyEBirdData.csv")
    main(sys.argv[1])
